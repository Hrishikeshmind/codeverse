import React from 'react';
import { NavLink } from 'react-router-dom';
import { Code, Github, Twitter, Linkedin, Youtube, Mail } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-900/80 backdrop-blur-lg border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <Code className="w-8 h-8 text-indigo-400" />
              <span className="text-2xl font-bold text-white">CodeVerse</span>
            </div>
            <p className="text-gray-400 mb-6">
              Empowering the next generation of developers with cutting-edge coding education.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-indigo-400 transition-colors">
                <Github className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-indigo-400 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-indigo-400 transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-indigo-400 transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Platform</h3>
            <ul className="space-y-3">
              <li>
                <NavLink to="/features" className="text-gray-400 hover:text-indigo-400 transition-colors">
                  Features
                </NavLink>
              </li>
              <li>
                <NavLink to="/courses" className="text-gray-400 hover:text-indigo-400 transition-colors">
                  Courses
                </NavLink>
              </li>
              <li>
                <NavLink to="/pricing" className="text-gray-400 hover:text-indigo-400 transition-colors">
                  Pricing
                </NavLink>
              </li>
              <li>
                <NavLink to="/about" className="text-gray-400 hover:text-indigo-400 transition-colors">
                  About Us
                </NavLink>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Resources</h3>
            <ul className="space-y-3">
              <li>
                <NavLink to="/blog" className="text-gray-400 hover:text-indigo-400 transition-colors">
                  Blog
                </NavLink>
              </li>
              <li>
                <NavLink to="/documentation" className="text-gray-400 hover:text-indigo-400 transition-colors">
                  Documentation
                </NavLink>
              </li>
              <li>
                <NavLink to="/community" className="text-gray-400 hover:text-indigo-400 transition-colors">
                  Community
                </NavLink>
              </li>
              <li>
                <NavLink to="/support" className="text-gray-400 hover:text-indigo-400 transition-colors">
                  Support
                </NavLink>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Newsletter</h3>
            <p className="text-gray-400 mb-4">
              Subscribe to our newsletter for the latest updates and coding tips.
            </p>
            <div className="flex">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-l-lg focus:outline-none focus:border-indigo-400 text-white"
              />
              <button className="px-4 py-2 bg-indigo-600 text-white rounded-r-lg hover:bg-indigo-700 transition-colors flex items-center">
                <Mail className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            © {new Date().getFullYear()} CodeVerse. All rights reserved.
          </p>
          <div className="flex space-x-6 text-sm">
            <a href="#" className="text-gray-400 hover:text-indigo-400 transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-gray-400 hover:text-indigo-400 transition-colors">
              Terms of Service
            </a>
            <a href="#" className="text-gray-400 hover:text-indigo-400 transition-colors">
              Cookie Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}