import React from 'react';
import { NavLink } from 'react-router-dom';
import { Code } from 'lucide-react';

export function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 p-6 z-50 bg-gray-900/80 backdrop-blur-lg">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <NavLink to="/" className="flex items-center space-x-2">
          <Code className="w-8 h-8 text-indigo-400" />
          <span className="text-2xl font-bold">CodeVerse</span>
        </NavLink>
        <div className="hidden md:flex space-x-8">
          <NavLink 
            to="/features" 
            className={({ isActive }) => 
              `hover:text-indigo-400 transition-colors ${isActive ? 'text-indigo-400' : 'text-white'}`
            }
          >
            Features
          </NavLink>
          <NavLink 
            to="/courses" 
            className={({ isActive }) => 
              `hover:text-indigo-400 transition-colors ${isActive ? 'text-indigo-400' : 'text-white'}`
            }
          >
            Courses
          </NavLink>
          <NavLink 
            to="/pricing" 
            className={({ isActive }) => 
              `hover:text-indigo-400 transition-colors ${isActive ? 'text-indigo-400' : 'text-white'}`
            }
          >
            Pricing
          </NavLink>
          <NavLink 
            to="/about" 
            className={({ isActive }) => 
              `hover:text-indigo-400 transition-colors ${isActive ? 'text-indigo-400' : 'text-white'}`
            }
          >
            About
          </NavLink>
        </div>
        <div className="flex space-x-4">
          <button className="px-4 py-2 rounded-lg bg-transparent border border-indigo-400 text-indigo-400 hover:bg-indigo-400 hover:text-white transition-all">
            Sign In
          </button>
          <button className="px-4 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition-colors">
            Get Started
          </button>
        </div>
      </div>
    </nav>
  );
}