import React, { useState } from 'react';
import CodeMirror from '@uiw/react-codemirror';
import { javascript } from '@codemirror/lang-javascript';
import { python } from '@codemirror/lang-python';
import { oneDark } from '@codemirror/theme-one-dark';
import { Play, Download, Copy, Layout, Users, Terminal, Check, Code2, Cpu, Folder, ChevronRight, ChevronDown, File, Settings } from 'lucide-react';

const languages = {
  javascript: {
    name: 'JavaScript',
    extension: 'js',
    mode: javascript(),
    template: '// Start coding here\nconsole.log("Hello, CodeVerse!");\n',
  },
  python: {
    name: 'Python',
    extension: 'py',
    mode: python(),
    template: '# Start coding here\nprint("Hello, CodeVerse!")\n',
  },
  typescript: {
    name: 'TypeScript',
    extension: 'ts',
    mode: javascript({ typescript: true }),
    template: '// Start coding here\nconst greeting: string = "Hello, CodeVerse!";\nconsole.log(greeting);\n',
  },
};

interface FileSystemItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  language?: string;
  children?: FileSystemItem[];
  expanded?: boolean;
}

const initialFileSystem: FileSystemItem[] = [
  {
    id: '1',
    name: 'src',
    type: 'folder',
    expanded: true,
    children: [
      {
        id: '2',
        name: 'main.ts',
        type: 'file',
        language: 'typescript',
      },
      {
        id: '3',
        name: 'components',
        type: 'folder',
        expanded: false,
        children: [
          {
            id: '4',
            name: 'App.tsx',
            type: 'file',
            language: 'typescript',
          },
        ],
      },
    ],
  },
  {
    id: '5',
    name: 'public',
    type: 'folder',
    expanded: false,
    children: [
      {
        id: '6',
        name: 'index.html',
        type: 'file',
      },
    ],
  },
];

export function CodeEditor() {
  const [code, setCode] = useState(languages.javascript.template);
  const [language, setLanguage] = useState('javascript');
  const [output, setOutput] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [showFileExplorer, setShowFileExplorer] = useState(true);
  const [fileSystem, setFileSystem] = useState(initialFileSystem);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [collaborators] = useState([
    { id: 1, name: 'Sarah Chen', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=50', status: 'active' },
    { id: 2, name: 'Alex Kim', avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=50', status: 'active' },
    { id: 3, name: 'Maya Patel', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=50', status: 'idle' },
  ]);

  const handleLanguageChange = (newLanguage: string) => {
    setLanguage(newLanguage);
    setCode(languages[newLanguage as keyof typeof languages].template);
  };

  const handleCopyCode = async () => {
    await navigator.clipboard.writeText(code);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleRunCode = () => {
    setIsRunning(true);
    setOutput('');
    
    setTimeout(() => {
      setOutput(`[${new Date().toLocaleTimeString()}] Running ${languages[language as keyof typeof languages].name} code...\n${code}\n\n> Output will appear here`);
      setIsRunning(false);
    }, 1000);
  };

  const toggleFolder = (id: string) => {
    const toggleExpanded = (items: FileSystemItem[]): FileSystemItem[] => {
      return items.map(item => {
        if (item.id === id) {
          return { ...item, expanded: !item.expanded };
        }
        if (item.children) {
          return { ...item, children: toggleExpanded(item.children) };
        }
        return item;
      });
    };
    setFileSystem(toggleExpanded(fileSystem));
  };

  const renderFileTree = (items: FileSystemItem[], level = 0) => {
    return items.map(item => (
      <div key={item.id} style={{ paddingLeft: `${level * 12}px` }}>
        <button
          onClick={() => item.type === 'folder' ? toggleFolder(item.id) : setSelectedFile(item.id)}
          className={`w-full flex items-center space-x-2 px-2 py-1 rounded-md hover:bg-gray-700/50 ${
            selectedFile === item.id ? 'bg-gray-700/50' : ''
          }`}
        >
          {item.type === 'folder' && (
            item.expanded ? <ChevronDown className="w-4 h-4 text-gray-400" /> : <ChevronRight className="w-4 h-4 text-gray-400" />
          )}
          {item.type === 'folder' ? (
            <Folder className="w-4 h-4 text-gray-400" />
          ) : (
            <File className="w-4 h-4 text-gray-400" />
          )}
          <span className="text-sm text-gray-300">{item.name}</span>
        </button>
        {item.children && item.expanded && renderFileTree(item.children, level + 1)}
      </div>
    ));
  };

  return (
    <div className="flex flex-col h-full bg-gray-900">
      <div className="flex items-center justify-between p-4 border-b border-gray-700">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 bg-gray-800 rounded-lg p-1">
            {Object.entries(languages).map(([key, lang]) => (
              <button
                key={key}
                onClick={() => handleLanguageChange(key)}
                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                  language === key
                    ? 'bg-indigo-600 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-gray-700'
                }`}
              >
                {lang.name}
              </button>
            ))}
          </div>
          <button
            onClick={handleRunCode}
            disabled={isRunning}
            className={`flex items-center space-x-2 px-4 py-2 ${
              isRunning
                ? 'bg-indigo-700 cursor-wait'
                : 'bg-indigo-600 hover:bg-indigo-700'
            } text-white rounded-lg transition-colors`}
          >
            {isRunning ? <Cpu className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
            <span>{isRunning ? 'Running...' : 'Run'}</span>
          </button>
        </div>
        <div className="flex items-center space-x-4">
          <button
            onClick={handleCopyCode}
            className="p-2 hover:bg-gray-800 rounded-lg transition-colors group relative"
            title="Copy code"
          >
            {isCopied ? <Check className="w-5 h-5 text-green-400" /> : <Copy className="w-5 h-5 text-gray-400 group-hover:text-white" />}
          </button>
          <button 
            onClick={() => setShowFileExplorer(!showFileExplorer)}
            className="p-2 hover:bg-gray-800 rounded-lg transition-colors group" 
            title="Toggle file explorer"
          >
            <Layout className="w-5 h-5 text-gray-400 group-hover:text-white" />
          </button>
          <button className="p-2 hover:bg-gray-800 rounded-lg transition-colors group" title="Download code">
            <Download className="w-5 h-5 text-gray-400 group-hover:text-white" />
          </button>
          <div className="flex items-center space-x-2 pl-4 border-l border-gray-700">
            <Users className="w-5 h-5 text-gray-400" />
            <div className="flex -space-x-2">
              {collaborators.map((user) => (
                <div key={user.id} className="relative">
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-8 h-8 rounded-full border-2 border-gray-900"
                    title={user.name}
                  />
                  <div
                    className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-gray-900 ${
                      user.status === 'active' ? 'bg-green-500' : 'bg-yellow-500'
                    }`}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex-1 flex overflow-hidden">
        {showFileExplorer && (
          <div className="w-64 border-r border-gray-700 bg-gray-900 p-4 overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-medium text-gray-300">Explorer</h2>
              <button className="p-1 hover:bg-gray-700 rounded-md">
                <Settings className="w-4 h-4 text-gray-400" />
              </button>
            </div>
            {renderFileTree(fileSystem)}
          </div>
        )}
        
        <div className="flex-1 grid grid-rows-2 overflow-hidden">
          <div className="overflow-auto">
            <CodeMirror
              value={code}
              height="100%"
              theme={oneDark}
              extensions={[languages[language as keyof typeof languages].mode]}
              onChange={(value) => setCode(value)}
              className="h-full"
              basicSetup={{
                lineNumbers: true,
                highlightActiveLineGutter: true,
                highlightSpecialChars: true,
                foldGutter: true,
                drawSelection: true,
                dropCursor: true,
                allowMultipleSelections: true,
                indentOnInput: true,
                bracketMatching: true,
                closeBrackets: true,
                autocompletion: true,
                rectangularSelection: true,
                crosshairCursor: true,
                highlightActiveLine: true,
                highlightSelectionMatches: true,
                closeBracketsKeymap: true,
                defaultKeymap: true,
                searchKeymap: true,
                historyKeymap: true,
                foldKeymap: true,
                completionKeymap: true,
                lintKeymap: true,
              }}
            />
          </div>
          
          <div className="border-t border-gray-700 bg-gray-900 p-4 font-mono text-sm overflow-auto">
            <div className="flex items-center space-x-2 mb-2">
              <Terminal className="w-4 h-4 text-gray-400" />
              <span className="text-gray-400">Output</span>
            </div>
            <pre className="text-gray-300 whitespace-pre-wrap">{output}</pre>
          </div>
        </div>
      </div>

      <div className="p-4 bg-gray-800 border-t border-gray-700">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="text-sm text-gray-400">Connected to CodeVerse Server</span>
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-400">
            <Code2 className="w-4 h-4" />
            <span>{languages[language as keyof typeof languages].name}</span>
          </div>
        </div>
      </div>
    </div>
  );
}