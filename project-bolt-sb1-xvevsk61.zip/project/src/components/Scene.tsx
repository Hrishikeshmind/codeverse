import { useRef, useEffect, useMemo } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { useGLTF, Float, Points, PointMaterial } from '@react-three/drei';
import * as THREE from 'three';
import gsap from 'gsap';

function generateSpherePoints(count: number) {
  const points = new Float32Array(count * 3);
  const radius = 3;
  
  for (let i = 0; i < count; i++) {
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos((Math.random() * 2) - 1);
    
    points[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
    points[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
    points[i * 3 + 2] = radius * Math.cos(phi);
  }
  
  return points;
}

export function Scene() {
  const groupRef = useRef<THREE.Group>(null);
  const sphereRef = useRef<THREE.Mesh>(null);
  const pointsRef = useRef<THREE.Points>(null);
  const { mouse, viewport } = useThree();
  
  const points = useMemo(() => generateSpherePoints(5000), []);

  useEffect(() => {
    if (groupRef.current) {
      gsap.to(groupRef.current.rotation, {
        y: Math.PI * 2,
        duration: 20,
        ease: "none",
        repeat: -1
      });
    }
  }, []);

  useFrame((state) => {
    if (sphereRef.current) {
      // Smooth mouse following
      sphereRef.current.position.x = THREE.MathUtils.lerp(
        sphereRef.current.position.x,
        mouse.x * viewport.width * 0.3,
        0.1
      );
      sphereRef.current.position.y = THREE.MathUtils.lerp(
        sphereRef.current.position.y,
        mouse.y * viewport.height * 0.3,
        0.1
      );
      
      // Breathing animation
      sphereRef.current.scale.x = sphereRef.current.scale.y = sphereRef.current.scale.z = 
        1 + Math.sin(state.clock.elapsedTime * 2) * 0.1;
    }

    if (pointsRef.current) {
      pointsRef.current.rotation.y = state.clock.elapsedTime * 0.1;
      pointsRef.current.rotation.z = state.clock.elapsedTime * 0.05;
    }
  });

  return (
    <>
      <color attach="background" args={['#050816']} />
      <fog attach="fog" args={['#050816', 15, 25]} />
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 10, 5]} intensity={1} />

      <group ref={groupRef}>
        <Float
          speed={1.5}
          rotationIntensity={1}
          floatIntensity={1}
        >
          <mesh ref={sphereRef} position={[0, 0, 0]}>
            <sphereGeometry args={[1, 64, 64]} />
            <meshStandardMaterial
              color="#4338ca"
              roughness={0.3}
              metalness={0.8}
              wireframe
            />
          </mesh>
        </Float>

        <Points ref={pointsRef}>
          <bufferGeometry>
            <bufferAttribute
              attach="attributes-position"
              count={points.length / 3}
              array={points}
              itemSize={3}
            />
          </bufferGeometry>
          <pointsMaterial
            size={0.02}
            color="#818cf8"
            sizeAttenuation
            transparent
            opacity={0.8}
          />
        </Points>

        {Array.from({ length: 50 }).map((_, i) => (
          <mesh
            key={i}
            position={[
              (Math.random() - 0.5) * 15,
              (Math.random() - 0.5) * 15,
              (Math.random() - 0.5) * 15
            ]}
          >
            <sphereGeometry args={[0.05, 16, 16]} />
            <meshStandardMaterial
              color="#818cf8"
              emissive="#818cf8"
              emissiveIntensity={0.5}
              transparent
              opacity={Math.random() * 0.5 + 0.5}
            />
          </mesh>
        ))}
      </group>

      <mesh position={[0, 0, -10]} rotation={[0, 0, 0]}>
        <planeGeometry args={[100, 100]} />
        <meshStandardMaterial
          color="#000000"
          opacity={0.5}
          transparent
          roughness={0.5}
          metalness={0}
        />
      </mesh>
    </>
  );
}