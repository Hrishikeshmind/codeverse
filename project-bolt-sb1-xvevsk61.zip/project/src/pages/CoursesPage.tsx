import React from 'react';
import { Star, Clock, Users, ArrowRight } from 'lucide-react';

export function CoursesPage() {
  const courses = [
    {
      title: "Web Development Fundamentals",
      description: "Learn HTML, CSS, and JavaScript from scratch and build responsive websites.",
      image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=500",
      level: "Beginner",
      duration: "8 weeks",
      students: 1234,
      rating: 4.8
    },
    {
      title: "React Mastery",
      description: "Master React.js and build modern web applications with advanced features.",
      image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=500",
      level: "Intermediate",
      duration: "10 weeks",
      students: 856,
      rating: 4.9
    },
    {
      title: "Python for Data Science",
      description: "Learn Python programming and essential data science libraries.",
      image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=500",
      level: "Intermediate",
      duration: "12 weeks",
      students: 2156,
      rating: 4.7
    },
    {
      title: "Full Stack Development",
      description: "Build complete web applications with modern front-end and back-end technologies.",
      image: "https://images.unsplash.com/photo-1537432376769-00f5c2f4c8d2?w=500",
      level: "Advanced",
      duration: "16 weeks",
      students: 943,
      rating: 4.9
    }
  ];

  return (
    <div className="min-h-screen bg-gray-900 pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold mb-6">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">
              Featured Courses
            </span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Learn from industry experts and advance your career with our comprehensive courses.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {courses.map((course, index) => (
            <div
              key={index}
              className="bg-gray-800/50 backdrop-blur-lg rounded-xl overflow-hidden border border-gray-700 hover:border-indigo-400 transition-all group"
            >
              <div className="aspect-video overflow-hidden">
                <img
                  src={course.image}
                  alt={course.title}
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="px-3 py-1 bg-indigo-600/20 text-indigo-400 rounded-full text-sm">
                    {course.level}
                  </span>
                  <div className="flex items-center space-x-1 text-yellow-400">
                    <Star className="w-4 h-4 fill-current" />
                    <span className="text-sm">{course.rating}</span>
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-3 text-white group-hover:text-indigo-400 transition-colors">
                  {course.title}
                </h3>
                <p className="text-gray-400 mb-6">
                  {course.description}
                </p>
                <div className="flex items-center justify-between text-sm text-gray-400">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{course.duration}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Users className="w-4 h-4" />
                      <span>{course.students.toLocaleString()} students</span>
                    </div>
                  </div>
                  <button className="flex items-center space-x-1 text-indigo-400 hover:text-indigo-300 transition-colors">
                    <span>Learn more</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <button className="px-8 py-4 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition-colors">
            View All Courses
          </button>
        </div>
      </div>
    </div>
  );
}