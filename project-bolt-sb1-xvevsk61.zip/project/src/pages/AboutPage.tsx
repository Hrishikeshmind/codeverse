import React from 'react';
import { Users, Trophy, BookOpen, Globe } from 'lucide-react';

export function AboutPage() {
  const stats = [
    { icon: <Users className="w-6 h-6" />, value: "100K+", label: "Active Students" },
    { icon: <Trophy className="w-6 h-6" />, value: "95%", label: "Success Rate" },
    { icon: <BookOpen className="w-6 h-6" />, value: "200+", label: "Courses" },
    { icon: <Globe className="w-6 h-6" />, value: "50+", label: "Countries" }
  ];

  const team = [
    {
      name: "Sarah Chen",
      role: "CEO & Founder",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300",
      bio: "Former Google engineer with a passion for education technology."
    },
    {
      name: "Alex Kim",
      role: "CTO",
      image: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=300",
      bio: "Tech leader with 15+ years of experience in EdTech."
    },
    {
      name: "Maya Patel",
      role: "Head of Education",
      image: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300",
      bio: "PhD in Computer Science Education, focused on innovative learning methods."
    }
  ];

  return (
    <div className="min-h-screen bg-gray-900 pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold mb-6">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">
              About CodeVerse
            </span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            We're on a mission to make coding education accessible, engaging, and effective for everyone.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-20">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="p-6 rounded-xl bg-gray-800/50 backdrop-blur-lg border border-gray-700 text-center"
            >
              <div className="w-12 h-12 rounded-lg bg-indigo-600/20 flex items-center justify-center mb-4 text-indigo-400 mx-auto">
                {stat.icon}
              </div>
              <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
              <div className="text-gray-400">{stat.label}</div>
            </div>
          ))}
        </div>

        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center mb-12">Our Leadership Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <div
                key={index}
                className="p-6 rounded-xl bg-gray-800/50 backdrop-blur-lg border border-gray-700 text-center group hover:border-indigo-400 transition-colors"
              >
                <div className="w-32 h-32 rounded-full overflow-hidden mx-auto mb-6">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">{member.name}</h3>
                <div className="text-indigo-400 mb-4">{member.role}</div>
                <p className="text-gray-400">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center">
          <h2 className="text-3xl font-bold mb-6">Join Our Mission</h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            We're always looking for passionate individuals to join our team and help shape the future of coding education.
          </p>
          <button className="px-8 py-4 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition-colors">
            View Open Positions
          </button>
        </div>
      </div>
    </div>
  );
}