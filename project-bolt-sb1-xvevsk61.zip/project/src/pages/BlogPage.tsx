import React from 'react';
import { Calendar, User, Clock, ArrowRight } from 'lucide-react';

export function BlogPage() {
  const posts = [
    {
      title: "Getting Started with Web Development in 2025",
      excerpt: "Learn the essential tools and technologies for modern web development.",
      image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=500",
      author: "Sarah Chen",
      date: "Mar 15, 2025",
      readTime: "5 min read",
      category: "Web Development"
    },
    {
      title: "The Future of AI in Coding Education",
      excerpt: "Discover how artificial intelligence is transforming the way we learn to code.",
      image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=500",
      author: "Alex Kim",
      date: "Mar 12, 2025",
      readTime: "7 min read",
      category: "AI & ML"
    },
    {
      title: "Building Scalable Applications with React",
      excerpt: "Best practices for creating large-scale React applications that perform.",
      image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=500",
      author: "Maya Patel",
      date: "Mar 10, 2025",
      readTime: "10 min read",
      category: "React"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-900 pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold mb-6">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">
              Latest Blog Posts
            </span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Stay updated with the latest trends, tutorials, and insights in coding and technology.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map((post, index) => (
            <article
              key={index}
              className="bg-gray-800/50 backdrop-blur-lg rounded-xl overflow-hidden border border-gray-700 hover:border-indigo-400 transition-all group"
            >
              <div className="aspect-video overflow-hidden">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="px-3 py-1 bg-indigo-600/20 text-indigo-400 rounded-full text-sm">
                    {post.category}
                  </span>
                </div>
                <h2 className="text-xl font-semibold mb-3 text-white group-hover:text-indigo-400 transition-colors">
                  {post.title}
                </h2>
                <p className="text-gray-400 mb-6">
                  {post.excerpt}
                </p>
                <div className="flex items-center justify-between text-sm text-gray-400">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <User className="w-4 h-4" />
                      <span>{post.author}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Calendar className="w-4 h-4" />
                      <span>{post.date}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{post.readTime}</span>
                    </div>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-12 text-center">
          <button className="px-8 py-4 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition-colors inline-flex items-center space-x-2">
            <span>View All Posts</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}