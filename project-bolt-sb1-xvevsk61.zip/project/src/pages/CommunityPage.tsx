import React from 'react';
import { Users, MessageSquare, Heart, Share2 } from 'lucide-react';

export function CommunityPage() {
  const discussions = [
    {
      title: "Best practices for learning React in 2025",
      content: "I'm new to React and wondering what's the most efficient way to learn it...",
      author: {
        name: "Alex Kim",
        avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100"
      },
      likes: 42,
      replies: 15,
      shares: 8,
      tags: ["React", "Learning", "Web Development"]
    },
    {
      title: "How to structure large-scale applications?",
      content: "Looking for advice on organizing a complex web application with multiple features...",
      author: {
        name: "Sarah Chen",
        avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100"
      },
      likes: 38,
      replies: 23,
      shares: 12,
      tags: ["Architecture", "Best Practices", "Web Development"]
    },
    {
      title: "Tips for optimizing React performance",
      content: "Share your best tips and tricks for improving React application performance...",
      author: {
        name: "Maya Patel",
        avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100"
      },
      likes: 56,
      replies: 31,
      shares: 19,
      tags: ["Performance", "React", "Optimization"]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-900 pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold mb-6">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">
              Community Discussions
            </span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Join the conversation with fellow developers and share your knowledge.
          </p>
          <button className="mt-8 px-8 py-4 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition-colors inline-flex items-center space-x-2">
            <MessageSquare className="w-5 h-5" />
            <span>Start a Discussion</span>
          </button>
        </div>

        <div className="grid gap-6">
          {discussions.map((discussion, index) => (
            <div
              key={index}
              className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700 hover:border-indigo-400 transition-all group"
            >
              <div className="flex items-start space-x-4">
                <img
                  src={discussion.author.avatar}
                  alt={discussion.author.name}
                  className="w-12 h-12 rounded-full"
                />
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-white group-hover:text-indigo-400 transition-colors mb-2">
                    {discussion.title}
                  </h3>
                  <p className="text-gray-400 mb-4">{discussion.content}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {discussion.tags.map((tag, tagIndex) => (
                      <span
                        key={tagIndex}
                        className="px-3 py-1 bg-indigo-600/20 text-indigo-400 rounded-full text-sm"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center justify-between text-sm text-gray-400">
                    <div className="flex items-center space-x-6">
                      <button className="flex items-center space-x-1 hover:text-indigo-400 transition-colors">
                        <Heart className="w-4 h-4" />
                        <span>{discussion.likes}</span>
                      </button>
                      <button className="flex items-center space-x-1 hover:text-indigo-400 transition-colors">
                        <MessageSquare className="w-4 h-4" />
                        <span>{discussion.replies}</span>
                      </button>
                      <button className="flex items-center space-x-1 hover:text-indigo-400 transition-colors">
                        <Share2 className="w-4 h-4" />
                        <span>{discussion.shares}</span>
                      </button>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-gray-400">{discussion.author.name}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 flex justify-center">
          <button className="px-8 py-4 rounded-lg bg-gray-800 text-white hover:bg-gray-700 transition-colors inline-flex items-center space-x-2">
            <span>Load More Discussions</span>
          </button>
        </div>
      </div>
    </div>
  );
}