import React from 'react';
import { Brain, Code2, Users, Rocket, Globe, Shield, Zap, MessageSquare } from 'lucide-react';

export function FeaturesPage() {
  const features = [
    {
      icon: <Brain className="w-8 h-8" />,
      title: "AI-Powered Learning",
      description: "Personalized learning paths and intelligent code suggestions powered by advanced AI algorithms."
    },
    {
      icon: <Code2 className="w-8 h-8" />,
      title: "Interactive IDE",
      description: "Full-featured development environment with real-time compilation and debugging capabilities."
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Collaborative Learning",
      description: "Work together in real-time with pair programming and shared workspaces."
    },
    {
      icon: <Rocket className="w-8 h-8" />,
      title: "Project-Based Learning",
      description: "Learn by building real-world projects with hands-on guidance and feedback."
    },
    {
      icon: <Globe className="w-8 h-8" />,
      title: "Global Community",
      description: "Connect with learners and mentors from around the world."
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Secure Environment",
      description: "Enterprise-grade security for your code and personal information."
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Instant Feedback",
      description: "Get immediate feedback on your code with automated testing and analysis."
    },
    {
      icon: <MessageSquare className="w-8 h-8" />,
      title: "Expert Support",
      description: "Access to experienced mentors and 24/7 technical support."
    }
  ];

  return (
    <div className="min-h-screen bg-gray-900 pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold mb-6">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">
              Powerful Features
            </span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Discover the tools and features that make CodeVerse the most advanced coding education platform.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="p-6 rounded-xl bg-gray-800/50 backdrop-blur-lg border border-gray-700 hover:border-indigo-400 transition-colors group"
            >
              <div className="w-12 h-12 rounded-lg bg-indigo-600/20 flex items-center justify-center mb-4 text-indigo-400 group-hover:text-indigo-300 transition-colors">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3 text-white group-hover:text-indigo-400 transition-colors">
                {feature.title}
              </h3>
              <p className="text-gray-400">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-20 text-center">
          <button className="px-8 py-4 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition-colors inline-flex items-center space-x-2">
            <Rocket className="w-5 h-5" />
            <span>Get Started Now</span>
          </button>
        </div>
      </div>
    </div>
  );
}