import React from 'react';
import { Check, Zap, Rocket, Crown } from 'lucide-react';

export function PricingPage() {
  const plans = [
    {
      name: "Basic",
      icon: <Zap className="w-6 h-6" />,
      price: "Free",
      description: "Perfect for getting started with coding",
      features: [
        "Access to basic courses",
        "Community forum access",
        "Basic code editor",
        "5 practice projects",
        "Email support"
      ],
      buttonText: "Get Started",
      popular: false
    },
    {
      name: "Pro",
      icon: <Rocket className="w-6 h-6" />,
      price: "$29",
      period: "per month",
      description: "Best for serious learners",
      features: [
        "All Basic features",
        "Advanced courses",
        "Live mentoring sessions",
        "Unlimited projects",
        "Priority support",
        "Certificate of completion",
        "AI-powered code review"
      ],
      buttonText: "Start Pro Trial",
      popular: true
    },
    {
      name: "Enterprise",
      icon: <Crown className="w-6 h-6" />,
      price: "Custom",
      description: "For teams and organizations",
      features: [
        "All Pro features",
        "Custom learning paths",
        "Dedicated success manager",
        "Team collaboration tools",
        "Analytics dashboard",
        "API access",
        "SSO integration",
        "Custom branding"
      ],
      buttonText: "Contact Sales",
      popular: false
    }
  ];

  return (
    <div className="min-h-screen bg-gray-900 pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold mb-6">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">
              Choose Your Plan
            </span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Get access to our platform with a plan that fits your learning needs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative p-8 rounded-xl backdrop-blur-lg border ${
                plan.popular
                  ? 'bg-indigo-600/10 border-indigo-400'
                  : 'bg-gray-800/50 border-gray-700'
              } hover:border-indigo-400 transition-colors group`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="px-4 py-1 bg-indigo-600 text-white text-sm rounded-full">
                    Most Popular
                  </div>
                </div>
              )}

              <div className={`w-12 h-12 rounded-lg ${
                plan.popular ? 'bg-indigo-600/20' : 'bg-gray-700'
              } flex items-center justify-center mb-6 text-indigo-400`}>
                {plan.icon}
              </div>

              <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
              <div className="mb-6">
                <span className="text-4xl font-bold text-white">{plan.price}</span>
                {plan.period && (
                  <span className="text-gray-400 ml-2">{plan.period}</span>
                )}
              </div>
              <p className="text-gray-400 mb-8">{plan.description}</p>

              <button className={`w-full px-6 py-3 rounded-lg ${
                plan.popular
                  ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                  : 'bg-gray-700 text-white hover:bg-gray-600'
              } transition-colors mb-8`}>
                {plan.buttonText}
              </button>

              <ul className="space-y-4">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center space-x-3 text-gray-300">
                    <Check className="w-5 h-5 text-indigo-400 flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-20 text-center">
          <h2 className="text-2xl font-bold mb-4">Need a Custom Solution?</h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Contact our team to create a custom plan that meets your specific requirements.
          </p>
          <button className="px-8 py-4 rounded-lg bg-transparent border border-indigo-400 text-indigo-400 hover:bg-indigo-400 hover:text-white transition-all">
            Contact Us
          </button>
        </div>
      </div>
    </div>
  );
}