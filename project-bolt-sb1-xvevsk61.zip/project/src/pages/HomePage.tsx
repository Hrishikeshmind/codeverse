import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { Scene } from '../components/Scene';
import { CodeEditor } from '../components/CodeEditor';
import { Brain, Code, Rocket, Users } from 'lucide-react';

export function HomePage() {
  return (
    <div className="relative w-full h-screen bg-gray-900 text-white overflow-hidden">
      <div className="absolute inset-0 z-0">
        <Canvas camera={{ position: [0, 0, 5] }}>
          <Suspense fallback={null}>
            <Scene />
          </Suspense>
        </Canvas>
      </div>

      <div className="relative z-10 h-full">
        <main className="h-full grid grid-cols-2 pt-24">
          <div className="flex items-center px-6">
            <div className="max-w-xl">
              <h1 className="text-6xl font-bold mb-6 leading-tight">
                The Next Generation
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400"> Coding Education </span>
                Platform
              </h1>
              <p className="text-xl text-gray-300 mb-8">
                Experience immersive learning with real-time collaboration, AI-powered assistance, and hands-on projects in our revolutionary 3D coding environment.
              </p>
              <div className="flex space-x-4">
                <button className="px-8 py-4 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition-colors flex items-center space-x-2">
                  <Rocket className="w-5 h-5" />
                  <span>Start Learning</span>
                </button>
                <button className="px-8 py-4 rounded-lg bg-transparent border border-indigo-400 text-indigo-400 hover:bg-indigo-400 hover:text-white transition-all">
                  Watch Demo
                </button>
              </div>

              <div className="grid grid-cols-3 gap-6 mt-16">
                <div className="p-4 rounded-xl bg-gray-800/50 backdrop-blur-lg">
                  <div className="w-10 h-10 rounded-lg bg-indigo-600/20 flex items-center justify-center mb-3">
                    <Brain className="w-5 h-5 text-indigo-400" />
                  </div>
                  <h3 className="text-lg font-semibold mb-1">AI-Powered</h3>
                  <p className="text-sm text-gray-400">Smart learning paths and real-time assistance</p>
                </div>
                <div className="p-4 rounded-xl bg-gray-800/50 backdrop-blur-lg">
                  <div className="w-10 h-10 rounded-lg bg-indigo-600/20 flex items-center justify-center mb-3">
                    <Code className="w-5 h-5 text-indigo-400" />
                  </div>
                  <h3 className="text-lg font-semibold mb-1">Live Coding</h3>
                  <p className="text-sm text-gray-400">Real-time collaboration tools</p>
                </div>
                <div className="p-4 rounded-xl bg-gray-800/50 backdrop-blur-lg">
                  <div className="w-10 h-10 rounded-lg bg-indigo-600/20 flex items-center justify-center mb-3">
                    <Users className="w-5 h-5 text-indigo-400" />
                  </div>
                  <h3 className="text-lg font-semibold mb-1">Community</h3>
                  <p className="text-sm text-gray-400">Learn and grow together</p>
                </div>
              </div>
            </div>
          </div>

          <div className="h-full pt-24 pb-6 pr-6">
            <div className="h-full rounded-lg overflow-hidden shadow-2xl border border-gray-800">
              <CodeEditor />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}